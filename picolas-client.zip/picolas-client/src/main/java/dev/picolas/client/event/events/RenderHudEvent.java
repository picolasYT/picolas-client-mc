package dev.picolas.client.event.events;

import net.minecraft.client.util.math.MatrixStack;

/** Fired during the 2-D HUD render pass (after vanilla HUD). */
public class RenderHudEvent {
    private final MatrixStack matrices;
    private final float tickDelta;

    public RenderHudEvent(MatrixStack matrices, float tickDelta) {
        this.matrices  = matrices;
        this.tickDelta = tickDelta;
    }

    public MatrixStack getMatrices() { return matrices;  }
    public float       getTickDelta() { return tickDelta; }
}
