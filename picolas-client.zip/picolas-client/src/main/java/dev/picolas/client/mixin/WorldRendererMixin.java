package dev.picolas.client.mixin;

import dev.picolas.client.PicolasClient;
import dev.picolas.client.event.events.RenderWorldEvent;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.util.math.MatrixStack;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(WorldRenderer.class)
public class WorldRendererMixin {

    @Inject(method = "render", at = @At("TAIL"))
    private void onRender(net.minecraft.client.render.RenderTickCounter tickCounter,
                          boolean renderBlockOutline,
                          net.minecraft.client.render.Camera camera,
                          net.minecraft.client.render.GameRenderer gameRenderer,
                          net.minecraft.client.render.LightmapTextureManager lightmapTextureManager,
                          Matrix4f matrix4f,
                          Matrix4f matrix4f2,
                          CallbackInfo ci) {
        MatrixStack matrices = new MatrixStack();
        matrices.multiplyPositionMatrix(matrix4f);
        PicolasClient.getInstance().getEventBus()
                .post(new RenderWorldEvent(matrices, tickCounter.getTickDelta(true)));
    }
}
